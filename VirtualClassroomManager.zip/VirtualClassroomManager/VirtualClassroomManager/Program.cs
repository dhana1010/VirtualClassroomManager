﻿namespace VirtualClassroomManager
{
    class Program
    {
        static void Main(string[] args)
        {
            var manager = new VCM();
            manager.Run();
        }
    }
}
