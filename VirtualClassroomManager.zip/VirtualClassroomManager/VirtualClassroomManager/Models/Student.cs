﻿namespace VirtualClassroomManager.Models
{
    public class Student
    {
        public string Id { get; set; }
        public Student(string id)
        {
            Id = id;
        }
    }
}
